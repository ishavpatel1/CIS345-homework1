#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pokemon.h"
#include "pokemon_io.h"
#include "pokemon_access.h"

#define MAX_CARDS 100
#define FILENAME "cards.txt"


int main()
{

    Pokemon cards[MAX_CARDS];
    int count = 0;
    FILE* infile = fopen(FILENAME, "r");
    if(infile){
        count = readCardList(cards, MAX_CARDS, infile);
        fclose(infile);
    }
    printf("%d cards loaded from the file. \n", count);

    int choice;
    char buffer[200];
    
    do{
        printf("\n----menu---\n");
        printf("1. Add Card\n");
        printf("2. Delete Card\n");
        printf("3. Display Call Cards\n");
        printf("4. Save and Exit Program\n");
        printf("Enter you number option: ");
        scanf("%d", &choice);
        getchar();
    
        if (choice == 1){
            if(count < MAX_CARDS){
                char tempName[50], tempType[30];
                int hp;
                float value;

                printf("Name: ");
                scanf("%49s", tempName);
                printf("Type: ");
                scanf("%29s", tempType);
                printf("Hit Points: ");
                scanf("%d", &hp);
                printf("Dollar Value: ");
                scanf("%f", &value);

                setName(&cards[count], tempName);
                setType(&cards[count], tempType);
                setHitPoints(&cards[count], hp);
                setDollarValue(&cards[count], value);

                count++;
            }
         else {
                printf("Card limit has been reached!\n");
            }
        } else if(choice == 2){
            char name[50];
            printf("Enter name of card to delete: ");
            scanf("%49s", name);

            int index = Find(count, cards, name);
            if (index >= 0){
                for (int i = index; i < count - 1; i++){
                    cards[i] = cards[i+1];
                }
                count--;
                printf("Card deleted.\n");
            } else {
                printf("Card no found.\n");
            }
        } else if (choice == 3){
            printf("\n---All Cards---\n");
            for(int i = 0; i < count; i++){
                toString(&cards[i], buffer);
                printf("%s\n", buffer);
            }
        } else if (choice == 4){
        FILE* outfile = fopen(FILENAME, "w");
        if (outfile){
            writeCardList(cards, count, outfile);
            fclose(outfile);
        }
        printf("Saved %d cards. Exiting...\n", count);
    } 
    }  while (choice != 4);
         return 0;
}



