#ifndef POKEMON_H
#define POKEMON_H

typedef struct{
    char name[50];
    char type[30];
    float dollarValue;
    int hitPoints;
} Pokemon;

#endif