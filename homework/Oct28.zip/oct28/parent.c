#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>

int main(int ac, char** a)
{
    if (ac != 3) {
        fprintf(stderr, "Usage: %s <child_executable> <count>\n", a[0]);
        return EXIT_FAILURE;
    }

    key_t key = 22;
    int size = 1, shmflg = 0;
    int id = 0, ok = 0, i = 0, count = 0;
    int *shmptr;
    int *pid_array;
    int status;
    char shmstr[10];
    char istr[10];

    count = atoi(a[2]);
    size = count * sizeof(int);

    pid_array = (int*) malloc(count * sizeof(int));
    if (pid_array == NULL) {
        perror("malloc");
        return EXIT_FAILURE;
    }

    shmflg = IPC_CREAT | SHM_R | SHM_W;

    id = shmget(key, size, shmflg);
    printf("%d get shmget\n", id);
    if (id == -1) {
        perror("shmget error");
        free(pid_array);
        return EXIT_FAILURE;
    }

    sprintf(shmstr, "%d", id);

    shmptr = shmat(id, 0, 0);
    if (shmptr == (int*)-1) {
        perror("shmat error");
        shmctl(id, IPC_RMID, 0);
        free(pid_array);
        return EXIT_FAILURE;
    }

    for (i = 0; i < count; i++) {
        shmptr[i] = 0;
    }

    for (i = 0; i < count; i++) {
        if ((pid_array[i] = fork()) == 0) {
            sprintf(istr, "%d", i);
            execlp(a[1], a[1], shmstr, istr, NULL);
            perror("execlp error in child");
            exit(EXIT_FAILURE);
        }
    }

    for (i = 0; i < count; i++) {
        ok = waitpid(pid_array[i], &status, 0);
        printf("%d wait on %d ok\n", ok, i);
    }

    printf("--- Final Results ---\n");
    printf("%d parent shmptr value at 0\n", shmptr[0]);

    ok = shmdt(shmptr);
    printf("%d parent detach ok\n", ok);

    ok = shmctl(id, IPC_RMID, 0);
    printf("%d parent remove ok\n", ok);

    free(pid_array);
    return EXIT_SUCCESS;
}
