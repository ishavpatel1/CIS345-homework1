#include <stdio.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <unistd.h>
#include <stdlib.h>

#define ITERATIONS 10000000

int main(int ac, char** a)
{
    if (ac != 3) {
        fprintf(stderr, "Usage: %s <shmid> <index>\n", a[0]);
        return EXIT_FAILURE;
    }

    int id = 0, ok = 0, i = 0, j = 0;
    int *shmptr;

    id = atoi(a[1]);
    i = atoi(a[2]);

    shmptr = shmat(id, 0, 0);
    if (shmptr == (int*)-1) {
        perror("shmat error in child");
        return EXIT_FAILURE;
    }

    printf("child %d shmptr index value %d\n", i, shmptr[i]);

    for (j = 0; j < ITERATIONS; j++) {
        shmptr[0] = shmptr[0] + 1;
        shmptr[0] = shmptr[0] - 1;
    }

    ok = shmdt(shmptr);
    printf("%d child detach ok\n", ok);

    return EXIT_SUCCESS;
}
