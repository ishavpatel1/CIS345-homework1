#include<stdio.h>
#include<stdlib.h>
//#include <iostream>

int compare(const void *a, const void *b){
    return (*(int*)a - *(int*)b);
}

int main(){
    int x, y, z;
    double median, mean = 0;

    printf("Please enter X Y Z: ");
    scanf("%d %d %d", &x, &y, &z);

    z = z+1;

    if(x > 10000 || x < 1){
        printf("ERROR: entered x is not in range\n");
        return 0;
    }

    if(y > z){
        printf("ERROR: y value is greater than x value\n");
        return 0;
    }

    int numbers[x];

    for(int i = 0; i < x; ++i){
        numbers[i] = (rand() % (z-y)) + y;
        mean = mean + numbers[i];
    }
    mean = mean/x;

    qsort(numbers, x, sizeof(numbers[0]), compare);

    printf("Numbers: ");
    for(int i = 0; i < x; ++i){
        printf("%d ", numbers[i]);
    }
    printf("\n");

    if(x%2 == 0){
        median = (numbers[x/2] + numbers[1 + x/2])/2;
    }
    else{
        median = numbers[(x+1)/2];
    }
    printf("Median: %f\n", median);

    printf("Mean: %f\n", mean);
}