#ifndef POKEMON_ACCESS_H
#define POKEMON_ACCESS_H

#include "pokemon.h"

void getName(PokemonCard* card, char* dest);
void setName(PokemonCard* card, const char* newName);

void getType(PokemonCard* card, char* dest);
void setType(PokemonCard* card, const char* newType);

int getHitPoints(PokemonCard* card);
void setHitPoints(PokemonCard* card, int newHP);

double getValue(PokemonCard* card);
void setValue(PokemonCard* card, double newValue);

void toString(PokemonCard* card, char* dest);
int getToStringLength(PokemonCard* card);

#endif