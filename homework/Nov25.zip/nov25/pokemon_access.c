#include <string.h>
#include <stdio.h>
#include "pokemon_access.h"

void getName(PokemonCard* card, char* dest) {
    strcpy(dest, card->name);
}
void setName(PokemonCard* card, const char* newName) {
    strncpy(card->name, newName, POKEMON_NAME_MAX-1);
    card->name[POKEMON_NAME_MAX-1] = '\0';
}

void getType(PokemonCard* card, char* dest) {
    strcpy(dest, card->type);
}
void setType(PokemonCard* card, const char* newType) {
    strncpy(card->type, newType, POKEMON_TYPE_MAX-1);
    card->type[POKEMON_TYPE_MAX-1] = '\0';
}

int getHitPoints(PokemonCard* card) {
    return card->hit_points;
}
void setHitPoints(PokemonCard* card, int newHP) {
    if (newHP < 0) newHP = 0;
    card->hit_points = newHP;
}

double getValue(PokemonCard* card) {
    return card->dollar_value;
}
void setValue(PokemonCard* card, double newValue) {
    if (newValue < 0.0) newValue = 0.0;
    card->dollar_value = newValue;
}

void toString(PokemonCard* card, char* dest) {
    sprintf(dest, "Name: %s | Type: %s | HP: %d | $%.2f",
            card->name, card->type, card->hit_points, card->dollar_value);
}

int getToStringLength(PokemonCard* card) {
    int needed = snprintf(NULL, 0, "Name: %s | Type: %s | HP: %d | $%.2f",
                          card->name, card->type, card->hit_points, card->dollar_value);
    return needed + 1;
}