#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#include "card_collection.h"
#include "pokemon_access.h"
#include "sorts.h" 

#define CMD_ADD 1
#define CMD_DELETE 2
#define CMD_LIST 3
#define CMD_SAVE 4
#define CMD_SORT 5
#define CMD_SAVE_AND_EXIT 6
#define CMD_EXIT_NO_SAVE 7

#define RES_DELETE_OK 5
#define RES_DELETE_FAIL 6

#define SHM_KEY_ID 0x58087
#define MAX_CARDS 5
#define SERVER_PORT 58087 
#define LISTEN_QUEUE_SIZE 1

#define SORT_BY_NAME 1
#define SORT_BY_HP   2
#define SORT_BY_VALUE 3

typedef struct {
    size_t size;
    PokemonCard data[MAX_CARDS];
    size_t name_indices[MAX_CARDS];
    size_t hp_indices[MAX_CARDS];
    size_t value_indices[MAX_CARDS];
    int current_sort;
} CardInventory;

static int parent_find_index_by_name(const CardInventory* inv, const char* name);
static int parent_compare_by_name(const void* a, const void* b);
static int parent_compare_by_hit_points(const void* a, const void* b);
static int parent_compare_by_value(const void* a, const void* b);
typedef int (*IndexCardCompareFunc)(const PokemonCard*, const PokemonCard*);
static void index_selection_sort(CardInventory* inv, size_t* indices, IndexCardCompareFunc compar);
static void initialize_index_arrays(CardInventory* inv);
static void update_index_arrays_for_new_card(CardInventory* inv, size_t new_card_idx);
static void update_index_arrays_for_delete(CardInventory* inv, size_t deleted_data_idx);
static int parent_add_card_from_struct(CardInventory* inv, const PokemonCard* card_data);
static int parent_delete_card_by_name(CardInventory* inv, const char* name);
static void parent_save_to_file(const CardInventory* inv, const char* path);
static void parent_load_from_file(CardInventory* inv, const char* path);

void server_process(int client_fd, CardInventory* inventory, const char* filepath);


int main(int argc, char *argv[]) {
    char initial_filepath[256] = "cards.txt";
    if (argc > 1) {
        strncpy(initial_filepath, argv[1], sizeof(initial_filepath) - 1);
        initial_filepath[sizeof(initial_filepath) - 1] = '\0';
    }

    int shm_id;
    CardInventory* inventory;
    size_t shm_size = sizeof(CardInventory);
    int listen_fd = -1, client_fd = -1;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);

    shm_id = shmget(SHM_KEY_ID, shm_size, IPC_CREAT | 0666);
    if (shm_id < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }
    printf("Shared memory segment (key 0x%x) created/accessed. Size: %zu bytes.\n", SHM_KEY_ID, shm_size);

    inventory = (CardInventory*)shmat(shm_id, NULL, 0);
    if (inventory == (CardInventory*)-1) {
        perror("shmat failed");
        shmctl(shm_id, IPC_RMID, NULL);
        exit(EXIT_FAILURE);
    }
    
    if (inventory->size == 0 && inventory->data[0].hit_points == 0) {
        memset(inventory, 0, shm_size);
        inventory->current_sort = SORT_BY_VALUE; 
    }

    printf("Attempting to load cards from '%s'...\n", initial_filepath);
    parent_load_from_file(inventory, initial_filepath);

    listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        perror("socket creation failed");
        goto cleanup;
    }

    int optval = 1;
    if (setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0) {
        perror("setsockopt failed");
        goto cleanup;
    }
    
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(SERVER_PORT);

    if (bind(listen_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind failed");
        goto cleanup;
    }

    if (listen(listen_fd, LISTEN_QUEUE_SIZE) < 0) {
        perror("listen failed");
        goto cleanup;
    }

    printf("Server listening on port %d. Waiting for client...\n", SERVER_PORT);

    client_fd = accept(listen_fd, (struct sockaddr*)&client_addr, &client_len);
    if (client_fd < 0) {
        perror("accept failed");
        goto cleanup;
    }

    printf("Client connected from %s:%d\n", 
           inet_ntoa(client_addr.sin_addr), 
           ntohs(client_addr.sin_port));

    close(listen_fd);
    listen_fd = -1;

    server_process(client_fd, inventory, initial_filepath);

cleanup:
    if (client_fd != -1) close(client_fd);
    if (listen_fd != -1) close(listen_fd);
    
    if (inventory != (CardInventory*)-1) {
        if (shmdt(inventory) == -1) {
            perror("shmdt failed");
        }
        if (shmctl(shm_id, IPC_RMID, NULL) == -1) {
            perror("shmctl IPC_RMID failed");
        }
        printf("Shared memory detached and removed.\n");
    }

    printf("Server shutting down. Goodbye!\n");
    return 0;
}


void server_process(int client_fd, CardInventory* inventory, const char* filepath) {
    int cmd;
    ssize_t bytes_read;
    printf("Server command loop started.\n");

    #define RECV_DATA(var) \
        bytes_read = recv(client_fd, &var, sizeof(var), 0); \
        if (bytes_read <= 0) { \
            if (bytes_read == 0) { printf("Client disconnected.\n"); } \
            else { perror("recv error"); } \
            return; \
        }

    #define SEND_DATA(var) \
        if (send(client_fd, &var, sizeof(var), 0) < 0) { \
            perror("send error"); \
            return; \
        }

    for (;;) {
        RECV_DATA(cmd);

        if (cmd == CMD_ADD) {
            PokemonCard card_data;
            RECV_DATA(card_data);

            int response;
            if (parent_add_card_from_struct(inventory, &card_data) == 0) {
                response = RES_DELETE_FAIL; 
            } else {
                response = RES_DELETE_OK;
            }
            SEND_DATA(response);

        } else if (cmd == CMD_DELETE) {
            char name[POKEMON_NAME_MAX];
            RECV_DATA(name);
            
            int status = parent_delete_card_by_name(inventory, name);
            int response = (status == 1) ? RES_DELETE_OK : RES_DELETE_FAIL;
            SEND_DATA(response);

        } else if (cmd == CMD_LIST) {
            size_t count = inventory->size;
            SEND_DATA(count);

            if (count == 0) continue; 

            size_t* current_indices = NULL;
            if (inventory->current_sort == SORT_BY_VALUE) current_indices = inventory->value_indices;
            else if (inventory->current_sort == SORT_BY_NAME) current_indices = inventory->name_indices;
            else if (inventory->current_sort == SORT_BY_HP) current_indices = inventory->hp_indices;
            
            for (size_t i = 0; i < count; i++) {
                size_t data_idx = (current_indices != NULL) ? current_indices[i] : i;
                SEND_DATA(inventory->data[data_idx]);
            }

        } else if (cmd == CMD_SAVE) {
            parent_save_to_file(inventory, filepath);

        } else if (cmd == CMD_SORT) {
            int sort_type;
            RECV_DATA(sort_type);

            if (sort_type == SORT_BY_VALUE || sort_type == SORT_BY_NAME || sort_type == SORT_BY_HP) {
                inventory->current_sort = sort_type;
            }

        } else if (cmd == CMD_SAVE_AND_EXIT) {
            parent_save_to_file(inventory, filepath);
            break;

        } else if (cmd == CMD_EXIT_NO_SAVE) {
            printf("Client requested exit without saving.\n");
            break;
        } else {
            printf("Received unknown command: %d\n", cmd);
        }
    }
    printf("Command loop finished. Closing connection.\n");
    
    #undef RECV_DATA
    #undef SEND_DATA
}



static int parent_find_index_by_name(const CardInventory* inv, const char* name) {
    for (size_t i = 0; i < inv->size; i++) {
        if (strncmp(inv->data[i].name, name, POKEMON_NAME_MAX) == 0) return (int)i;
    }
    return -1;
}

static int parent_compare_by_name(const void* a, const void* b) {
    const PokemonCard* cardA = (const PokemonCard*)a;
    const PokemonCard* cardB = (const PokemonCard*)b;
    return strcmp(cardA->name, cardB->name);
}

static int parent_compare_by_hit_points(const void* a, const void* b) {
    const PokemonCard* cardA = (const PokemonCard*)a;
    const PokemonCard* cardB = (const PokemonCard*)b;
    return cardA->hit_points - cardB->hit_points;
}

static int parent_compare_by_value(const void* a, const void* b) {
    const PokemonCard* cardA = (const PokemonCard*)a;
    const PokemonCard* cardB = (const PokemonCard*)b;
    if (cardA->dollar_value < cardB->dollar_value) return -1;
    if (cardA->dollar_value > cardB->dollar_value) return 1;
    return 0;
}


static void index_selection_sort(CardInventory* inv, size_t* indices, IndexCardCompareFunc compar) {
    if (inv->size < 2) {
        return;
    }

    for (size_t i = 0; i < inv->size - 1; i++) {
        size_t min_idx_pos = i; 

        for (size_t j = i + 1; j < inv->size; j++) {
            size_t current_min_data_idx = indices[min_idx_pos];
            size_t current_data_idx = indices[j];
            
            const PokemonCard* elem1 = &(inv->data[current_min_data_idx]);
            const PokemonCard* elem2 = &(inv->data[current_data_idx]);

            if (compar(elem1, elem2) > 0) {
                min_idx_pos = j;
            }
        }

        if (min_idx_pos != i) {
            size_t temp = indices[i];
            indices[i] = indices[min_idx_pos];
            indices[min_idx_pos] = temp;
        }
    }
}


static void initialize_index_arrays(CardInventory* inv) {
    for (size_t i = 0; i < inv->size; i++) {
        inv->name_indices[i] = i;
        inv->hp_indices[i] = i;
        inv->value_indices[i] = i;
    }
}

static void update_index_arrays_for_new_card(CardInventory* inv, size_t new_card_idx) {
    inv->name_indices[new_card_idx] = new_card_idx;
    inv->hp_indices[new_card_idx] = new_card_idx;
    inv->value_indices[new_card_idx] = new_card_idx;
    
    index_selection_sort(inv, inv->name_indices, parent_compare_by_name);
    index_selection_sort(inv, inv->hp_indices, parent_compare_by_hit_points);
    index_selection_sort(inv, inv->value_indices, parent_compare_by_value);
}

static void update_index_arrays_for_delete(CardInventory* inv, size_t deleted_data_idx) {
    
    void update_single_index_array(size_t* indices) {
        for (size_t i = 0; i < inv->size + 1; i++) { 
            size_t data_idx = indices[i];
            if (data_idx == deleted_data_idx) {
                for (size_t j = i; j < inv->size; j++) {
                    indices[j] = indices[j+1];
                }
                break; 
            } else if (data_idx > deleted_data_idx) {
                indices[i]--;
            }
        }
    }

    update_single_index_array(inv->name_indices);
    update_single_index_array(inv->hp_indices);
    update_single_index_array(inv->value_indices);
}


static int parent_add_card_from_struct(CardInventory* inv, const PokemonCard* card_data) {
    if (inv->size >= MAX_CARDS) {
        return 0;
    }

    size_t new_card_idx = inv->size;
    inv->data[new_card_idx] = *card_data;
    inv->size++;
    
    update_index_arrays_for_new_card(inv, new_card_idx);
    
    return 1;
}

static int parent_delete_card_by_name(CardInventory* inv, const char* name) {
    int idx = parent_find_index_by_name(inv, name);
    if (idx < 0) { return 0; }

    size_t deleted_data_idx = (size_t)idx;

    for (size_t i = deleted_data_idx + 1; i < inv->size; i++) {
        inv->data[i - 1] = inv->data[i];
    }
    inv->size--;
    
    update_index_arrays_for_delete(inv, deleted_data_idx);

    return 1;
}



static void parent_save_to_file(const CardInventory* inv, const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) { perror("fopen"); return; }
    for (size_t i = 0; i < inv->size; i++) {
        fprintf(f, "%s\t%s\t%d\t%.2f\n",
            inv->data[i].name,
            inv->data[i].type,
            inv->data[i].hit_points,
            inv->data[i].dollar_value);
    }
    fclose(f);
    printf("Saved %zu card(s) to '%s'.\n", inv->size, path);
}

static void parent_chomp(char* s) {
    if (!s) return;
    size_t n = strlen(s);
    if (n > 0 && s[n-1] == '\n') s[n-1] = '\0';
}


static void parent_load_from_file(CardInventory* inv, const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) return;

    char line[256];
    size_t initial_size = inv->size;
    while (fgets(line, sizeof line, f)) {
        parent_chomp(line);
        if (line[0] == '\0') continue;

        if (inv->size >= MAX_CARDS) break;

        PokemonCard c_data;
        char name[POKEMON_NAME_MAX], type[POKEMON_TYPE_MAX];
        int hp; double val;

        if (sscanf(line, "%63[^\t]\t%31[^\t]\t%d\t%lf", name, type, &hp, &val) == 4) {
            setName(&c_data, name); setType(&c_data, type);
            setHitPoints(&c_data, hp); setValue(&c_data, val);

            inv->data[inv->size] = c_data;
            inv->size++;
        }
    }
    if (inv->size > initial_size) {
        printf("Loaded %zu card(s) from '%s'.\n", inv->size - initial_size, path);
        
        initialize_index_arrays(inv);
        index_selection_sort(inv, inv->name_indices, parent_compare_by_name);
        index_selection_sort(inv, inv->hp_indices, parent_compare_by_hit_points);
        index_selection_sort(inv, inv->value_indices, parent_compare_by_value);
    }
    fclose(f);
}