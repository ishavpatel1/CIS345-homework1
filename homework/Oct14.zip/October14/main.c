#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h> // For signal handling
#include <unistd.h> // For write() and alarm()
#include "card_collection.h"

// --- Global State for Inactivity Alarm ---
static CardArray* g_cards = NULL;
static const char* g_filepath = "pokedex_autosave.txt";
static volatile sig_atomic_t g_inactivity_level = 0;

// --- Signal Handler for SIGALRM ---
static void alarm_handler(int signum) {
    (void)signum;

    const char* msg;
    int next_alarm_time = 0;

    // The prompt to show after any message
    const char* prompt_suffix = "Input a menu button to resume activity: ";

    if (g_inactivity_level == 0) {
        msg = "\n[SYSTEM] Inactivity detected. Program will shut down in 10 seconds.\n";
        g_inactivity_level = 1;
        next_alarm_time = 5; // Total 10 seconds: 5s + 5s
    } else if (g_inactivity_level == 1) {
        msg = "\n[SYSTEM] No interaction. Program will shut down in five seconds.\n";
        g_inactivity_level = 2;
        next_alarm_time = 4; // Total 10 seconds: 5s + 4s + 1s
    } else if (g_inactivity_level == 2) {
        // This is the last warning. next_alarm_time will be 1
        msg = "\n[SYSTEM] FINAL WARNING. Program will shut down in 1 second.\n";
        g_inactivity_level = 3;
        next_alarm_time = 1;
    } else {
        // g_inactivity_level == 3 (Shutdown)
        msg = "\n[SYSTEM] Program shutting down due to inactivity.\n";
        if (write(STDOUT_FILENO, msg, strlen(msg)) < 0) { /* Ignore */ }

        if (g_cards && g_filepath) {
            save_to_file(g_cards, g_filepath);
        }
        _exit(EXIT_FAILURE);
    }
    
    // Print the warning message
    if (write(STDOUT_FILENO, msg, strlen(msg)) < 0) { /* Ignore */ }
    
    // Print the prompt suffix immediately after the message
    if (write(STDOUT_FILENO, prompt_suffix, strlen(prompt_suffix)) < 0) { /* Ignore */ }

    alarm(next_alarm_time);
}

// --- User Input and Menu ---
static int prompt_main_menu_choice(const char* prompt) {
    char line[128];
    int choice;
    
    fputs(prompt, stdout);
    fflush(stdout);

    if (!fgets(line, sizeof line, stdin)) {
        clearerr(stdin);
        return -1;
    }

    // Reset inactivity timer and level on any successful input attempt
    // This is the only place we reset g_inactivity_level and restart the alarm
    // for the main menu, and it happens AFTER the input is received.
    g_inactivity_level = 0;
    alarm(5); // Reset timer to 5 seconds.

    if (sscanf(line, "%d", &choice) != 1) {
        return -2;
    }
    return choice;
}

static void menu() {
    puts("\nMenu:");
    puts("1) Add card");
    puts("2) Delete card (by name)");
    puts("3) List cards");
    puts("4) Save to file");
    puts("5) Sort cards");
    puts("6) Exit");
}

// --- Main Program Logic ---
int main(void) {
    // ... (rest of main function setup remains the same) ...
    const char* initial_filepath = "cards.txt";
    g_cards = create_collection();

    // --- SETUP SIGNAL HANDLER WITH SIGACTION ---
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa)); // Zero out the struct
    sa.sa_handler = alarm_handler; // Set our handler function
    // The SA_RESTART flag helps automatically restart interrupted system calls
    sa.sa_flags = SA_RESTART;
    // Apply the action for the SIGALRM signal
    if (sigaction(SIGALRM, &sa, NULL) == -1) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }
    // --- END OF SETUP ---

    printf("Attempting to load cards from '%s'...\n", initial_filepath);
    load_from_file(g_cards, initial_filepath);

    if (get_collection_size(g_cards) > 0) {
        g_filepath = initial_filepath;
    } else {
        puts("No cards loaded (file missing or empty). Starting new collection.");
        printf("Data will be auto-saved to '%s' on inactive shutdown.\n", g_filepath);
    }

    alarm(5); // Start the initial 5-second inactivity timer

    for (;;) {
        menu();
        int choice = prompt_main_menu_choice("Select: ");

        // Disable alarm *before* executing a function that requires user input
        // and re-enable it *after*.

        if (choice == 1) {
            alarm(0); // Cancel the current alarm
            add_card(g_cards);
            alarm(5); // Restart the alarm
        }
        else if (choice == 2) {
            alarm(0); // Cancel the current alarm
            delete_card(g_cards);
            alarm(5); // Restart the alarm
        }
        else if (choice == 3) {
            list_cards(g_cards);
            // No alarm restart needed, as list_cards has no user input.
            // The alarm was already reset by prompt_main_menu_choice.
        }
        else if (choice == 4) {
            save_to_file(g_cards, g_filepath);
            // No alarm restart needed.
        }
        else if (choice == 5) {
            alarm(0); // Cancel the current alarm
            sort_cards(g_cards);
            alarm(5); // Restart the alarm
        }
        else if (choice == 6) {
            char ans[8];
            
            // Disable alarm before prompting for save/exit
            alarm(0);
            fputs("Save before exit? (y/n): ", stdout);
            fflush(stdout);
            if (fgets(ans, sizeof ans, stdin)) {
                if (ans[0] == 'y' || ans[0] == 'Y') {
                    save_to_file(g_cards, g_filepath);
                }
            }
            break;
        } else {
            if (choice != -1) {
                 puts("Invalid choice.");
            }
        }
    }

    free_collection(g_cards);
    puts("Goodbye!");
    return 0;
}