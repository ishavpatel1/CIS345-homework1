#ifndef SORTS_H
#define SORTS_H

#include <stddef.h> // For size_t

/**
 * @brief Sorts an array in place using the selection sort algorithm.
 *
 * This is a generic implementation that can sort any type of array,
 * provided a suitable comparison function.
 *
 * @param base A pointer to the start of the array to be sorted.
 * @param num The number of elements in the array.
 * @param size The size (in bytes) of each element in the array.
 * @param compar A function pointer that compares two elements.
 * It should return < 0 if a < b, 0 if a == b, > 0 if a > b.
 */
void selection_sort(void* base, size_t num, size_t size, int (*compar)(const void*, const void*));

#endif // SORTS_H