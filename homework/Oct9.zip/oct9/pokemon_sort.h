#ifndef POKEMON_SORT_H
#define POKEMON_SORT_H

#include "pokemon.h"

void selectionSort(Pokemon* arr[], int n, int(*compare)(const Pokemon*, const Pokemon*));

#endif