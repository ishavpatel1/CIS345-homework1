#include <stdio.h>
#include "pokemon_sort.h"

void selectionSort(Pokemon* arr[], int n, int (*compare)(const Pokemon*, const Pokemon*)){
    for(int i = 0; i < n-1; i++){
        int minIndex = i;
        for(int j = i + 1; j<n; j++){
            if(compare(arr[j], arr[minIndex]) < 0){
                minIndex = j;
            }
        }
        if(minIndex != i){
            Pokemon* temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
}