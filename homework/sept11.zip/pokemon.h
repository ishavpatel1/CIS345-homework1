#ifndef POKEMON_H
#define POKEMON_H

typedef struct{
    char name[50];
    char type[30];
    float dollarValue;
    double hitPoints;
} Pokemon;

#endif