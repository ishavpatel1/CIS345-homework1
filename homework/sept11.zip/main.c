#include <stdio.h>
#include "pokemon.h"

#define NUM_CARDS 3

int main()
{
    Pokemon cards[NUM_CARDS];
    
    for (int i = 0; i < NUM_CARDS; i++)
    {
        printf("Enter the data for the Pokemon card %d:\n", i + 1);

        printf("Name: ");
        scanf("%49s", cards[i].name);

        printf("Type (Electric, Water...): ");
        scanf("%29s", cards[i].type);

        printf("Hit points: ");
        scanf("%lf", &cards[i].hitPoints);

        printf("Dollar Value: ");
        scanf("%f", &cards[i].dollarValue);

        while (getchar() != '\n');

        printf("\n");
    }

    printf("--Display format 1: Name, Type, Hit Points, Dollar Value --\n");
    for (int i = 0; i < NUM_CARDS; i++)
    {
        printf("%s, %s, %.2lf, $%.2f\n",
               cards[i].name,
               cards[i].type,
               cards[i].hitPoints,
               cards[i].dollarValue);
    }

    printf("\n");

    printf("--Display format 2: Dollar Value, Hit Points, Name, Type --\n");
    for (int i = 0; i < NUM_CARDS; i++)
    {
        printf("$%.2f, %.2lf, %s, %s\n",
               cards[i].dollarValue,
               cards[i].hitPoints,
               cards[i].name,
               cards[i].type);
    }

    return 0;
}
