#include "subtract.h"

long subtract(long a, long b){
    return a - b;
}