#include "add.h"

long add(long x, long y){
    return x + y;
}