#include <stdio.h>
#include "add.h"
#include "subtract.h"
#include "mult.h"
#include "intDiv.h"
#include "execute.h"

int main() {
    long a, b;

    printf("Enter the first integer:\n ");
    scanf("%ld", &a);
    printf("Enter second integer: \n");
    scanf("%ld", &b);


printf("Add: %ld\n", execute(a, b, add));
printf("Subtract: %ld\n", execute(a, b, subtract));
printf("Multiply: %ld\n", execute(a, b, mult));
printf("Divide: %ld\n", execute(a, b, intDiv));

return 0;
}