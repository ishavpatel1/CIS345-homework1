#ifndef EXECUTE_H
#define EXECUTE_H

long execute(long w, long z, long arithmetic(long, long));

#endif