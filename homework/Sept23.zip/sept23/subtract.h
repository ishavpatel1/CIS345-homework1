#ifndef SUBTRACT_H
#define SUBTRACT_H

long subtract(long a, long b);
#endif