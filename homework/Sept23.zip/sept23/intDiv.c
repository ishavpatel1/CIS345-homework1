#include "intDiv.h"

long intDiv(long f, long g){
    if(g == 0){
        return 0;
    } else {
       return f/g;
    }
}