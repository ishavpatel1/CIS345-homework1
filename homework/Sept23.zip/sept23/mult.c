#include "mult.h"

long mult (long c , long d){
    return c * d;
}