#ifndef INTDIV_H
#define INTDIV_H

long intDiv(long f, long g);

#endif
