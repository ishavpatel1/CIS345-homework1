#ifndef ADD_H
#define ADD_H

long add(long x, long y);

#endif 