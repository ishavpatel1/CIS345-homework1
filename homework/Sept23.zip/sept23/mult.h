#ifndef MULT_H
#define MULT_H

long mult(long c, long d);

#endif 

