#include "execute.h"

long execute(long w, long z, long arithmetic(long, long)){
    return arithmetic(w,z);
}