#ifndef POKEMON_H
#define POKEMON_H

#define POKEMON_NAME_MAX 64
#define POKEMON_TYPE_MAX 32

typedef struct {
    char name[POKEMON_NAME_MAX];
    char type[POKEMON_TYPE_MAX];
    int  hit_points;
    double dollar_value;
} PokemonCard;

#endif