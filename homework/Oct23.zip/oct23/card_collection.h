#ifndef CARD_COLLECTION_H
#define CARD_COLLECTION_H

// Forward declaration of the CardArray struct to hide implementation details.
typedef struct CardArray CardArray;

// --- Public Interface ---

CardArray* create_collection(void);
void free_collection(CardArray* arr);
void load_from_file(CardArray* arr, const char* path);
void save_to_file(const CardArray* arr, const char* path);
void add_card(CardArray* arr);
void delete_card(CardArray* arr);
void list_cards(const CardArray* arr);

// New function to handle sorting the collection
void sort_cards(CardArray* arr);

// Function to get the current number of cards
size_t get_collection_size(const CardArray* arr);

#endif // CARD_COLLECTION_H