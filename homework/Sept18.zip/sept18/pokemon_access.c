#include <string.h>
#include <stdio.h>
#include "pokemon_access.h"

void getName(Pokemon* theRecord, char* spotToCopyName){
    strcpy(spotToCopyName, theRecord->name);
}

void getType(Pokemon* theRecord, char* spotToCopyType){
    strcpy(spotToCopyType, theRecord->type);
}

int getHitPoints(Pokemon* theRecord){
    return theRecord->hitPoints;
}

float getDollarValue(Pokemon* theRecord){
    return theRecord->dollarValue;
}

void setName(Pokemon* theRecord, const char* newName){
    strncpy(theRecord->name, newName, sizeof(theRecord->name)-1);
    theRecord-> name[sizeof(theRecord->name)-1] = '\0';
}

void setType(Pokemon* theRecord, const char* newType) {
    strncpy(theRecord-> type, newType, sizeof(theRecord->type) - 1);
    theRecord-> type[sizeof(theRecord->type) - 1] = '\0';
}

void setHitPoints(Pokemon* theRecord, int newHitPoints){
    theRecord->hitPoints = newHitPoints;
}

void setDollarValue(Pokemon* theRecord, float newDollarValue){
    theRecord->dollarValue = newDollarValue;
}

void toString(Pokemon* theRecord, char* plactToPutTheString) {
    sprintf(plactToPutTheString, "%s, %s, %d, $%.2f",
            theRecord -> name,
            theRecord ->type,
            theRecord ->hitPoints,
            theRecord ->dollarValue);
}

int getToStringLength(Pokemon* theRecord) {
    char buffer[200];
    toString(theRecord, buffer);
    return strlen(buffer) + 1;
}

int Find(int arraylen, Pokemon* theArray, char* theName){
    for (int i = 0; i < arraylen; i++){
        if(strcmp(theArray[i].name, theName) == 0){
            return i;
        }
    }

    return -1;
}

