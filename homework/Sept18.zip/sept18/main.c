#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pokemon.h"
#include "pokemon_access.h"

#define MAX_CARDS 100
#define FILENAME "card.txt"

int loadCards(Pokemon cards [], int max);
void saveCards(Pokemon cards[], int count);

int main()
{

    Pokemon cards[MAX_CARDS];
    int count = loadCards(cards, MAX_CARDS);
    printf("%d cards loaded from the file. \n", count);

    int choice;
    char buffer[200];
    
    do{
        printf("\n----menu---\n");
        printf("1. Add Card\n");
        printf("2. Delete Card\n");
        printf("3. Display Call Cards\n");
        printf("4. Save and Exit Program\n");
        printf("Enter you number option: ");
        scanf("%d", &choice);
        getchar();
    
        if (choice == 1){
            if(count < MAX_CARDS){
                char tempName[50], tempType[30];
                int hp;
                float value;

                printf("Name: ");
                scanf("%49s", tempName);
                printf("Type: ");
                scanf("%29s", tempType);
                printf("Hit Points: ");
                scanf("%d", &hp);
                printf("Dollar Value: ");
                scanf("%f", &value);

                setName(&cards[count], tempName);
                setType(&cards[count], tempType);
                setHitPoints(&cards[count], hp);
                setDollarValue(&cards[count], value);

                count++;
            }
         else {
                printf("Card limit has been reached!\n");
            }
        } else if(choice == 2){
            char name[50];
            printf("Enter name of card to delete: ");
            scanf("%49s", name);

            int index = Find(count, cards, name);
            if (index >= 0){
                for (int i = index; i < count - 1; i++){
                    cards[i] = cards[i+1];
                }
                count--;
                printf("Card deleted.\n");
            } else {
                printf("Card no found.\n");
            }
        } else if (choice == 3){
            printf("\n---All Cards---");
            for(int i = 0; i < count; i++){
                toString(&cards[i], buffer);
                printf("%s\n", buffer);
            }
        } else if (choice == 4){
        saveCards(cards, count);
        printf("Saved %d cards. Exiting...\n", count);
    } 
    }  while (choice != 4);
         return 0;
}

    int loadCards(Pokemon cards[], int max){
        FILE* file = fopen(FILENAME, "r");
        if(!file) return 0;

        int count;
        if (fscanf(file, "%d\n", &count) != 1){
            fclose(file);
            return 0;
        }
        if(count > max) count = max;

        for(int i = 0; i < count; i++){
            fgets(cards[i].name, sizeof(cards[i].name), file);
            cards[i].name[strcspn(cards[i].name, "\n")] = '\0';

            fgets(cards[i].type, sizeof(cards[i].type), file);
            cards[i].type[strcspn(cards[i].name, "\n")] = '\0';

        fscanf(file, "%d\n", &cards[i].hitPoints);
        fscanf(file, "%f\n", &cards[i].dollarValue);
        }
        
        fclose(file);
        return count;
    }

    void saveCards(Pokemon cards[], int count){
        FILE* file = fopen(FILENAME, "w");
        if (!file) { 
            printf("Error saving file! OH no!\n");
            return;
        }

        fprintf(file, "%d\n", count);
        for (int i = 0; i < count; i++){
            fprintf(file, "%s\n", cards[i].name);
            fprintf(file, "%s\n", cards[i].type);
            fprintf(file, "%d\n", cards[i].hitPoints);
            fprintf(file, "%.2f\n", cards[i].dollarValue);
        }

        fclose(file);
    }

