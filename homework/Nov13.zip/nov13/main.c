#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include "card_collection.h"
#include "pokemon.h"
#include "pokemon_access.h"
#include "sorts.h"

#define CMD_ADD 1
#define CMD_DELETE 2
#define CMD_LIST 3
#define CMD_SAVE 4
#define CMD_SORT 5
#define CMD_SAVE_AND_EXIT 6
#define CMD_EXIT_NO_SAVE 7

#define RES_DELETE_OK 5
#define RES_DELETE_FAIL 6

#define SHM_KEY_ID 0x58087
#define MAX_CARDS 5

typedef struct {
    size_t size;
    PokemonCard data[MAX_CARDS];
} CardInventory;

void parent_process(int read_fd, int write_fd, CardInventory* inventory, const char* filepath);
void child_process(int read_fd, int write_fd);

static int parent_find_index_by_name(const CardInventory* inv, const char* name) {
    for (size_t i = 0; i < inv->size; i++) {
        if (strncmp(inv->data[i].name, name, POKEMON_NAME_MAX) == 0) return (int)i;
    }
    return -1;
}

static int parent_compare_by_name(const void* a, const void* b) {
    const PokemonCard* cardA = (const PokemonCard*)a;
    const PokemonCard* cardB = (const PokemonCard*)b;
    return strcmp(cardA->name, cardB->name);
}

static int parent_compare_by_hit_points(const void* a, const void* b) {
    const PokemonCard* cardA = (const PokemonCard*)a;
    const PokemonCard* cardB = (const PokemonCard*)b;
    return cardA->hit_points - cardB->hit_points;
}

static int parent_compare_by_value(const void* a, const void* b) {
    const PokemonCard* cardA = (const PokemonCard*)a;
    const PokemonCard* cardB = (const PokemonCard*)b;
    if (cardA->dollar_value < cardB->dollar_value) return -1;
    if (cardA->dollar_value > cardB->dollar_value) return 1;
    return 0;
}

static int parent_add_card_from_struct(CardInventory* inv, const PokemonCard* card_data) {
    if (inv->size >= MAX_CARDS) {
        return 0;
    }

    inv->data[inv->size] = *card_data;
    inv->size++;
    return 1;
}

static int parent_delete_card_by_name(CardInventory* inv, const char* name) {
    int idx = parent_find_index_by_name(inv, name);
    if (idx < 0) { return 0; }

    for (size_t i = (size_t)idx + 1; i < inv->size; i++) {
        inv->data[i - 1] = inv->data[i];
    }
    inv->size--;
    return 1;
}

static void parent_save_to_file(const CardInventory* inv, const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) { perror("fopen"); return; }
    for (size_t i = 0; i < inv->size; i++) {
        fprintf(f, "%s\t%s\t%d\t%.2f\n",
            inv->data[i].name,
            inv->data[i].type,
            inv->data[i].hit_points,
            inv->data[i].dollar_value);
    }
    fclose(f);
    printf("Saved %zu card(s) to '%s'.\n", inv->size, path);
}

static void parent_load_from_file(CardInventory* inv, const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) return;

    char line[256];
    while (fgets(line, sizeof line, f)) {
        size_t n = strlen(line);
        if (n > 0 && line[n-1] == '\n') line[n-1] = '\0';
        if (line[0] == '\0') continue;

        if (inv->size >= MAX_CARDS) break;

        PokemonCard c_data;
        char name[POKEMON_NAME_MAX], type[POKEMON_TYPE_MAX];
        int hp; double val;

        if (sscanf(line, "%63[^\t]\t%31[^\t]\t%d\t%lf", name, type, &hp, &val) == 4) {
            setName(&c_data, name); setType(&c_data, type);
            setHitPoints(&c_data, hp); setValue(&c_data, val);

            inv->data[inv->size] = c_data;
            inv->size++;
        }
    }
    if (inv->size > 0) {
        printf("Loaded %zu card(s) from '%s'.\n", inv->size, path);
    }
    fclose(f);
}


static volatile sig_atomic_t g_child_inactivity_level = 0;

static void child_alarm_handler(int signum) {
    (void)signum;
    const char* msg;
    int next_alarm_time = 0;
    const char* prompt_suffix = "Input a menu button to resume activity: ";

    if (g_child_inactivity_level == 0) {
        msg = "\nInactivity detected. Program will shut down in 10 seconds.\n";
        g_child_inactivity_level = 1;
        next_alarm_time = 5;
    } else if (g_child_inactivity_level == 1) {
        msg = "\nNo interaction. Program will shut down in five seconds.\n";
        g_child_inactivity_level = 2;
        next_alarm_time = 4;
    } else if (g_child_inactivity_level == 2) {
        msg = "\nFINAL WARNING. Program will shut down in 1 second.\n";
        g_child_inactivity_level = 3;
        next_alarm_time = 1;
    } else {
        msg = "\nProgram shutting down due to inactivity.\n";
        if (write(STDOUT_FILENO, msg, strlen(msg)) < 0) { }

        _exit(EXIT_FAILURE);
    }

    if (write(STDOUT_FILENO, msg, strlen(msg)) < 0) { }
    if (write(STDOUT_FILENO, prompt_suffix, strlen(prompt_suffix)) < 0) { }
    alarm(next_alarm_time);
}

static void child_menu() {
    puts("\nMenu:");
    puts("1) Add card");
    puts("2) Delete card (by name)");
    puts("3) List cards");
    puts("4) Save to file");
    puts("5) Sort cards");
    puts("6) Exit");
}

static void child_chomp(char* s) {
    if (!s) return;
    size_t n = strlen(s);
    if (n > 0 && s[n-1] == '\n') s[n-1] = '\0';
}

static void child_prompt_line(const char* prompt, char* buf, size_t size) {
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(buf, (int)size, stdin)) { clearerr(stdin); continue; }
        child_chomp(buf);
        if (buf[0] == '\0') { puts("Input cannot be empty."); continue; }
        return;
    }
}

static int child_prompt_int(const char* prompt) {
    char line[128]; int v;
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { clearerr(stdin); continue; }
        if (sscanf(line, "%d", &v) == 1 && v >= 0) return v;
        puts("Enter a non-negative integer: ");
    }
}

static double child_prompt_double(const char* prompt) {
    char line[128]; double v;
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { clearerr(stdin); continue; }
        if (sscanf(line, "%lf", &v) == 1 && v >= 0.0) return v;
        puts("Enter a non-negative number (e.g., 12.34): ");
    }
}

static int child_prompt_menu_choice(const char* prompt) {
    char line[128];
    int choice;

    fputs(prompt, stdout);
    fflush(stdout);

    if (!fgets(line, sizeof line, stdin)) {
        clearerr(stdin);
        return -1;
    }

    g_child_inactivity_level = 0;
    alarm(5);

    if (sscanf(line, "%d", &choice) != 1) {
        return -2;
    }
    return choice;
}

static void child_request_list(int read_fd, int write_fd) {
    int cmd = CMD_LIST;
    write(write_fd, &cmd, sizeof(cmd));

    size_t count;
    read(read_fd, &count, sizeof(count));

    if (count == 0) {
        puts("(no cards)");
        return;
    }

    PokemonCard card;
    for (size_t i = 0; i < count; i++) {
        read(read_fd, &card, sizeof(card));
        printf("%zu) Name: %s | Type: %s | HP: %d | $%.2f\n",
               i + 1, card.name, card.type, card.hit_points, card.dollar_value);
    }
}

int main(void) {
    char initial_filepath[256];
    int shm_id;
    CardInventory* inventory;

    printf("Enter inventory filename: ");
    if(!fgets(initial_filepath, sizeof(initial_filepath), stdin)) {
        strcpy(initial_filepath, "cards.txt");
    }
    child_chomp(initial_filepath);

    size_t shm_size = sizeof(CardInventory);

    shm_id = shmget(SHM_KEY_ID, shm_size, IPC_CREAT | 0666);
    if (shm_id < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }
    printf("Shared memory segment (key 0x%x) created/accessed. Size: %zu bytes.\n", SHM_KEY_ID, shm_size);

    inventory = (CardInventory*)shmat(shm_id, NULL, 0);
    if (inventory == (CardInventory*)-1) {
        perror("shmat failed");
        shmctl(shm_id, IPC_RMID, NULL);
        exit(EXIT_FAILURE);
    }

    if (inventory->size == 0 && inventory->data[0].hit_points == 0) {
        memset(inventory, 0, shm_size);
    }

    printf("Attempting to load cards from '%s'...\n", initial_filepath);
    parent_load_from_file(inventory, initial_filepath);

    int pipe_c2p[2];
    int pipe_p2c[2];

    if (pipe(pipe_c2p) == -1 || pipe(pipe_p2c) == -1) {
        perror("pipe");
        shmdt(inventory);
        shmctl(shm_id, IPC_RMID, NULL);
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        shmdt(inventory);
        shmctl(shm_id, IPC_RMID, NULL);
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        close(pipe_c2p[0]);
        close(pipe_p2c[1]);

        child_process(pipe_p2c[0], pipe_c2p[1]);

        close(pipe_p2c[0]);
        close(pipe_c2p[1]);
        exit(0);

    } else {
        close(pipe_c2p[1]);
        close(pipe_p2c[0]);

        parent_process(pipe_c2p[0], pipe_p2c[1], inventory, initial_filepath);

        close(pipe_c2p[0]);
        close(pipe_p2c[1]);

        wait(NULL);
        printf("Child process terminated. Cleaning up.\n");

        if (shmdt(inventory) == -1) {
            perror("shmdt failed");
        }
        if (shmctl(shm_id, IPC_RMID, NULL) == -1) {
            perror("PARENT: shmctl IPC_RMID failed");
        }

        printf("Shared memory detached and removed. Goodbye!\n");
    }

    return 0;
}

void parent_process(int read_fd, int write_fd, CardInventory* inventory, const char* filepath) {
    int cmd;
    printf("Process started. Waiting for child commands.\n");

    while (read(read_fd, &cmd, sizeof(cmd)) > 0) {

        if (cmd == CMD_ADD) {
            PokemonCard card_data;
            read(read_fd, &card_data, sizeof(card_data));

            if (parent_add_card_from_struct(inventory, &card_data) == 0) {
                int response = RES_DELETE_FAIL;
                write(write_fd, &response, sizeof(response));
            } else {
                int response = RES_DELETE_OK;
                write(write_fd, &response, sizeof(response));
            }

        } else if (cmd == CMD_DELETE) {
            char name[POKEMON_NAME_MAX];
            read(read_fd, &name, sizeof(name));
            int status = parent_delete_card_by_name(inventory, name);
            int response = (status == 1) ? RES_DELETE_OK : RES_DELETE_FAIL;
            write(write_fd, &response, sizeof(response));

        } else if (cmd == CMD_LIST) {
            size_t count = inventory->size;
            write(write_fd, &count, sizeof(count));
            for (size_t i = 0; i < count; i++) {
                write(write_fd, &(inventory->data[i]), sizeof(PokemonCard));
            }

        } else if (cmd == CMD_SAVE) {
            parent_save_to_file(inventory, filepath);


        } else if (cmd == CMD_SORT) {
            int sort_type;
            read(read_fd, &sort_type, sizeof(sort_type));

            typedef int (*CardCompareFunc)(const void*, const void*);
            CardCompareFunc sorter = NULL;

            if (sort_type == 1) sorter = parent_compare_by_name;
            else if (sort_type == 2) sorter = parent_compare_by_hit_points;
            else if (sort_type == 3) sorter = parent_compare_by_value;

            if (sorter) {
                selection_sort(inventory->data, inventory->size, sizeof(PokemonCard), sorter);
            }


        } else if (cmd == CMD_SAVE_AND_EXIT) {
            parent_save_to_file(inventory, filepath);
            break;

        } else if (cmd == CMD_EXIT_NO_SAVE) {
            printf("Exited without saving.\n");
            break;
        }
    }

    printf("Command loop finished. Shutting down.\n");
}

void child_process(int read_fd, int write_fd) {

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = child_alarm_handler;
    sa.sa_flags = SA_RESTART;
    if (sigaction(SIGALRM, &sa, NULL) == -1) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }

    alarm(5);

    for (;;) {
        child_menu();
        int choice = child_prompt_menu_choice("Select: ");
        int cmd;

        if (choice == 1) {
            alarm(0);
            PokemonCard new_card;
            char buf[128];

            child_prompt_line("Name: ", buf, sizeof buf);         setName(&new_card, buf);
            child_prompt_line("Type: ", buf, sizeof buf);         setType(&new_card, buf);
            setHitPoints(&new_card, child_prompt_int("Hit Points: "));
            setValue(&new_card, child_prompt_double("Dollar Value: "));

            cmd = CMD_ADD;
            write(write_fd, &cmd, sizeof(cmd));
            write(write_fd, &new_card, sizeof(new_card));

            int response;
            read(read_fd, &response, sizeof(response));
            if (response == RES_DELETE_OK) {
                puts("Card data sent to be added.");
            } else {
                puts("Inventory is full. Card not added.");
            }

            alarm(5);
        }
        else if (choice == 2) {
            alarm(0);
            char name[POKEMON_NAME_MAX];
            child_prompt_line("Name of card to delete: ", name, sizeof name);

            cmd = CMD_DELETE;
            write(write_fd, &cmd, sizeof(cmd));
            write(write_fd, &name, sizeof(name));

            int response;
            read(read_fd, &response, sizeof(response));
            if (response == RES_DELETE_OK) puts("Card deleted.");
            else puts("Card not found.");

            alarm(5);
        }
        else if (choice == 3) {
            puts("\n--- Current Cards ---");
            child_request_list(read_fd, write_fd);
        }
        else if (choice == 4) {
            cmd = CMD_SAVE;
            write(write_fd, &cmd, sizeof(cmd));
            puts("Save command sent.");
        }
        else if (choice == 5) {
            alarm(0);
            puts("\nSort by:");
            puts("1) Name");
            puts("2) Hit Points");
            puts("3) Dollar Value");
            int sort_choice = child_prompt_int("Select: ");

            if (sort_choice >= 1 && sort_choice <= 3) {
                cmd = CMD_SORT;
                write(write_fd, &cmd, sizeof(cmd));
                write(write_fd, &sort_choice, sizeof(sort_choice));

                puts("\n--- Sorted Cards ---");
                child_request_list(read_fd, write_fd);
            } else {
                puts("Invalid choice. No sort performed.");
            }
            alarm(5);
        }
        else if (choice == 6) {
            alarm(0);
            char ans[8];
            child_prompt_line("Save before exit? (y/n): ", ans, sizeof(ans));

            if (ans[0] == 'y' || ans[0] == 'Y') {
                cmd = CMD_SAVE_AND_EXIT;
                write(write_fd, &cmd, sizeof(cmd));
                puts("Save command sent. Exiting.");
            } else {
                cmd = CMD_EXIT_NO_SAVE;
                write(write_fd, &cmd, sizeof(cmd));
                puts("Exiting without saving.");
            }
            break;
        } else {
            if (choice != -1) {
                 puts("Invalid choice.");
            }
        }
    }
    printf("Goodbye!!\n");
}