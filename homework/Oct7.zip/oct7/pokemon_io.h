#ifndef POKEMON_IO_H
#define POKEMON_IO_H

#include <stdio.h>
#include "pokemon.h"

void readName (char* name, int size, FILE* infile);

int readCard(Pokemon* c, FILE* infile);

void writeCard(Pokemon*, FILE* outfile);

int readCardList(Pokemon cards[], int max, FILE* infile);

void writeCardList(Pokemon cards[], int count, FILE* outfile);


#endif 