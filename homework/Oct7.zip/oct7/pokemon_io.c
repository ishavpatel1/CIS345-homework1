#include <string.h>
#include <stdio.h>
#include "pokemon_io.h"

void readName(char* name, int size, FILE* infile){
    if(fgets(name, size, infile)){
        name[strcspn(name, "\n")] = '\0';
    }
}

int readCard(Pokemon* c, FILE* infile){
    if(!fgets(c->name, sizeof(c->name), infile)) return 0;
    c->name[strcspn(c->name, "\n")] = '\0';

    if(!fgets(c->type, sizeof(c->type), infile)) return 0;
    c->type[strcspn(c->type, "\n")] = '\0';

    if(fscanf(infile, "%d\n", &c->hitPoints) != 1) return 0;
    if(fscanf(infile, "%f\n", &c->dollarValue) != 1) return 0;

    return 1;

}

void writeCard(Pokemon*c, FILE* outfile){
    fprintf(outfile, "%s\n", c->name);
    fprintf(outfile, "%s\n", c->type);
    fprintf(outfile, "%d\n", c->hitPoints);
    fprintf(outfile, "%.2f\n", c->dollarValue);
}

int readCardList(Pokemon cards[], int max, FILE* infile){
    int count;
    if(fscanf(infile, "%d\n", &count) != 1) return 0;
    if(count > max) count = max;

    for(int i = 0; i <count; i++){
        if(!readCard(&cards[i], infile)) return i;
    }
    return count; 
}

void writeCardList(Pokemon cards[], int count, FILE* outfile){
    fprintf(outfile, "%d\n", count);
    for(int i = 0; i < count; i++){
        writeCard(&cards[i], outfile);
    }
}