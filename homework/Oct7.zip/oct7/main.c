#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pokemon.h"
#include "pokemon_io.h"
#include "pokemon_access.h"

#define INITIAL_CAPACITY 10
#define FILENAME "cards.txt"

int compareByHP(const void* a, const void* b){
    Pokemon* pa = *(Pokemon**)a;
    Pokemon* pb = *(Pokemon**)b;
    return pa -> hitPoints - pb-> hitPoints;
}


int main()
{

    Pokemon** cards = malloc(INITIAL_CAPACITY * sizeof(Pokemon*));
    int capacity = INITIAL_CAPACITY;
    int count = 0;
    char buffer[200];
    
    FILE* infile = fopen(FILENAME, "r");
    if(infile){
        int n;
        fscanf(infile, "%d\n", &n);
        for(int i = 0; i < n; i++){
            if(count == capacity){
                capacity *= 2;
                cards = realloc(cards, capacity * sizeof(Pokemon*));
            }
            cards[count] = malloc(sizeof(Pokemon));
            if(readCard(cards[count], infile)){
                count++;
            } else {
                free(cards[count]);
            }
        }
        fclose(infile);
    }
    printf("%d cards loaded from the file. \n", count);

    int choice;
    do{
        printf("\n----menu---\n");
        printf("1. Add Card\n");
        printf("2. Delete Card\n");
        printf("3. Display Call Cards\n");
        printf("4. Compare by HP\n");
        printf("5. Compare by Value\n");
        printf("6. Compare by Name\n ");
        printf("7. Save and Exit Porgram\n");
        printf("Enter you number option: ");
        scanf("%d", &choice);
        getchar();
    
        if (choice == 1){
            if(count == capacity){
                capacity *= 2;
                cards = realloc(cards, capacity * sizeof(Pokemon*));
            }
            cards[count] = malloc(sizeof(Pokemon));

                char tempName[50], tempType[30];
                int hp;
                float value;

                printf("Name: ");
                scanf("%49s", tempName);
                printf("Type: ");
                scanf("%29s", tempType);
                printf("Hit Points: ");
                scanf("%d", &hp);
                printf("Dollar Value: ");
                scanf("%f", &value);

                setName(cards[count], tempName);
                setType(cards[count], tempType);
                setHitPoints(cards[count], hp);
                setDollarValue(cards[count], value);

                count++;

        } else if(choice == 2){
            char name[50];
            printf("Enter name of card to delete: ");
            scanf("%49s", name);

            int index = Find(count, cards, name);
            if (index >= 0){
                for (int i = index; i < count - 1; i++){
                    cards[i] = cards[i+1];
                }
                count--;
                printf("Card deleted.\n");
            } else {
                printf("Card no found.\n");
            }
        } else if (choice == 3){
            printf("\n---All Cards---\n");
            for(int i = 0; i < count; i++){
                toString(cards[i], buffer);
                printf("%d. %s\n", i, buffer);
            }
        } else if (choice == 4){
            printf("\n--Compare by HP--\n");
            if (count < 2){
                printf("Need at least 2 cards to compare");
            } else {
                for(int i = 0; i < count; i++){
                toString(cards[i], buffer);
                printf("%d. %s\n", i, buffer);
                 }
                int i1, i2;
                printf("Enter index of first card (0 - %d): ", count - 1);
                scanf("%d", &i1);
                printf("Enter index of second card (0 - %d): ", count -1);
                scanf("%d", &i2);

                int result = compareByHitPoints(cards[i1], cards[i2]);
                if(result == 0)
                    printf("\n Cards have equal Hit Points.\n");
                else if (result < 0)
                    printf("\n %s has fewer Hit Points than %s. \n", cards[i1] ->name, cards[i2]->name);
                else
                    printf("\n %s has more Hit Points than %s.\n", cards[i1] -> name, cards[i2]->name);
            
            }

    } else if(choice == 5){
        printf("\n--Sorted by Dollar Value--\n");
         if (count < 2){
                printf("Need at least 2 cards to compare");
            } else {
                for(int i = 0; i < count; i++){
                toString(cards[i], buffer);
                printf("%d. %s\n", i, buffer);
                }
                int i1, i2;
                printf("Enter index of first card (0 - %d): ", count -1);
                scanf("%d", &i1);
                printf("Enter index of second card (0 - %d): ", count -1);
                scanf("%d", &i2);

                int result = compareByValue(cards[i1], cards[i2]);
                if(result == 0)
                    printf("\n Cards have equal Dollar Value.\n");
                else if (result < 0)
                    printf("\n %s is cheaper than %s.\n", cards[i1] ->name, cards[i2]->name);
                else
                    printf("\n %s is more expensive then %s.\n", cards[i1] -> name, cards[i2]->name);
            
            }

    } else if(choice == 6){
        printf("\n--Sorted by Name--\n");
         if (count < 2){
                printf("Need at least 2 cards to compare.");
            } else {
                for(int i = 0; i < count; i++){
                toString(cards[i], buffer);
                printf("%d. %s\n", i, buffer);
                }
                
                int i1, i2;
                printf("Enter index of first card (0 - %d): ", count - 1);
                scanf("%d", &i1);
                printf("Enter index of second card (0 - %d): ", count - 1);
                scanf("%d", &i2);

                int result = compareByName(cards[i1], cards[i2]);
                if(result == 0)
                    printf("\n Cards have the same Name.\n");
                else if (result < 0)
                    printf("\n %s comes before %s alphabetically.\n", cards[i1] ->name, cards[i2]->name);
                else
                    printf("\n %s comes after %s alphabetically \n", cards[i1] -> name, cards[i2]->name);
            
            }
      } else if(choice == 7){
        FILE* outfile = fopen(FILENAME, "w");
        if (outfile){
            fprintf(outfile, "%d\n", count);
            for(int i = 0; i < count; i++){
                writeCard(cards[i], outfile);
            }
            fclose(outfile);
        }
        printf("Saved %d cards. Exiting...\n", count);
    }
}  while (choice != 7);

for(int i =0; i < count; i++){
    free(cards[i]);
}
    free(cards);

  return 0;
}



