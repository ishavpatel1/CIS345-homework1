#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#include "pokemon.h" 
#include "pokemon_access.h" 

#define CMD_ADD 1
#define CMD_DELETE 2
#define CMD_LIST 3
#define CMD_SAVE 4
#define CMD_SORT 5
#define CMD_SAVE_AND_EXIT 6
#define CMD_EXIT_NO_SAVE 7

#define RES_DELETE_OK 5
#define RES_DELETE_FAIL 6

#define SERVER_PORT 58087 

static volatile sig_atomic_t g_child_inactivity_level = 0;

static void child_alarm_handler(int signum);
static void child_menu();
static void child_chomp(char* s);
static void child_prompt_line(const char* prompt, char* buf, size_t size);
static int child_prompt_int(const char* prompt);
static double child_prompt_double(const char* prompt);
static int child_prompt_menu_choice(const char* prompt);
static void client_request_list(int server_fd);

void client_process(int server_fd);

int main(void) {
    char server_ip[64];
    int server_fd = -1;
    struct sockaddr_in server_addr;

    printf("Enter Server IP Address (e.g., 127.0.0.1 or lab-machine-name): ");
    if(!fgets(server_ip, sizeof(server_ip), stdin)) {
        strcpy(server_ip, "127.0.0.1"); 
    }
    child_chomp(server_ip);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);

    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        fprintf(stderr, "Invalid address/Address not supported: %s\n", server_ip);
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Connecting to server at %s:%d...\n", server_ip, SERVER_PORT);

    if (connect(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("connection failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server.\n");

    client_process(server_fd);

    close(server_fd);
    printf("Connection closed. Goodbye!!\n");
    return 0;
}


void client_process(int server_fd) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = child_alarm_handler;
    sa.sa_flags = SA_RESTART;
    if (sigaction(SIGALRM, &sa, NULL) == -1) {
        perror("sigaction");
    }
    alarm(5); 

    #define RECV_DATA(var) \
        if (recv(server_fd, &var, sizeof(var), 0) < 0) { \
            perror("recv error"); \
            return; \
        }

    #define SEND_DATA(var) \
        if (send(server_fd, &var, sizeof(var), 0) < 0) { \
            perror("send error"); \
            return; \
        }
    
    for (;;) {
        child_menu();
        int choice = child_prompt_menu_choice("Select: ");
        int cmd;

        if (choice == 1) {
            alarm(0);
            PokemonCard new_card;
            char buf[128];

            child_prompt_line("Name: ", buf, sizeof buf);         setName(&new_card, buf);
            child_prompt_line("Type: ", buf, sizeof buf);         setType(&new_card, buf);
            setHitPoints(&new_card, child_prompt_int("Hit Points: "));
            setValue(&new_card, child_prompt_double("Dollar Value: "));

            cmd = CMD_ADD;
            SEND_DATA(cmd);
            SEND_DATA(new_card);

            int response;
            RECV_DATA(response);
            if (response == RES_DELETE_OK) {
                puts("Card data sent to be added. Collection re-indexed.");
            } else {
                puts("Inventory is full. Card not added.");
            }

            alarm(5);
        }
        else if (choice == 2) {
            alarm(0);
            char name[POKEMON_NAME_MAX];
            child_prompt_line("Name of card to delete: ", name, sizeof name);

            cmd = CMD_DELETE;
            SEND_DATA(cmd);
            SEND_DATA(name);

            int response;
            RECV_DATA(response);
            if (response == RES_DELETE_OK) puts("Card deleted. Collection re-indexed.");
            else puts("Card not found.");

            alarm(5);
        }
        else if (choice == 3) {
            puts("\n--- Current Cards (Sorted) ---");
            client_request_list(server_fd);
        }
        else if (choice == 4) { 
            cmd = CMD_SAVE;
            SEND_DATA(cmd);
            puts("Save command sent.");
        }
        else if (choice == 5) { 
            alarm(0);
            puts("\nSort by:");
            puts("1) Name");
            puts("2) Hit Points");
            puts("3) Dollar Value");
            int sort_choice = child_prompt_int("Select: ");

            if (sort_choice >= 1 && sort_choice <= 3) {
                cmd = CMD_SORT;
                SEND_DATA(cmd);
                SEND_DATA(sort_choice);

                const char* sort_key = "Unknown";
                if (sort_choice == 1) sort_key = "Name";
                else if (sort_choice == 2) sort_key = "Hit Points";
                else if (sort_choice == 3) sort_key = "Dollar Value";
                
                printf("\n--- Card listing order set to %s ---\n", sort_key);
            } else {
                puts("Invalid choice. No sort order change performed.");
            }
            alarm(5);
        }
        else if (choice == 6) {
            alarm(0);
            char ans[8];
            child_prompt_line("Save before exit? (y/n): ", ans, sizeof(ans));

            if (ans[0] == 'y' || ans[0] == 'Y') {
                cmd = CMD_SAVE_AND_EXIT;
            } else {
                cmd = CMD_EXIT_NO_SAVE;
            }
            SEND_DATA(cmd);
            break;
        } else {
            if (choice != -1) {
                 puts("Invalid choice.");
            }
        }
    }
    
    #undef RECV_DATA
    #undef SEND_DATA
}

static void client_request_list(int server_fd) {
    int cmd = CMD_LIST;
    if (send(server_fd, &cmd, sizeof(cmd), 0) < 0) {
        perror("send error");
        return;
    }

    size_t count;
    if (recv(server_fd, &count, sizeof(count), 0) <= 0) {
        perror("recv error (count)");
        return;
    }

    if (count == 0) {
        puts("(no cards)");
        return;
    }

    PokemonCard card;
    for (size_t i = 0; i < count; i++) {
        if (recv(server_fd, &card, sizeof(card), 0) <= 0) {
            perror("recv error (card)");
            return;
        }
        printf("%zu) Name: %s | Type: %s | HP: %d | $%.2f\n",
               i + 1, card.name, card.type, card.hit_points, card.dollar_value);
    }
}


static void child_alarm_handler(int signum) {
    (void)signum;
    const char* msg;
    int next_alarm_time = 0;
    const char* prompt_suffix = "Input a menu button to resume activity: ";

    if (g_child_inactivity_level == 0) {
        msg = "\nInactivity detected. Program will shut down in 10 seconds.\n";
        g_child_inactivity_level = 1;
        next_alarm_time = 5;
    } else if (g_child_inactivity_level == 1) {
        msg = "\nNo interaction. Program will shut down in five seconds.\n";
        g_child_inactivity_level = 2;
        next_alarm_time = 4;
    } else if (g_child_inactivity_level == 2) {
        msg = "\nFINAL WARNING. Program will shut down in 1 second.\n";
        g_child_inactivity_level = 3;
        next_alarm_time = 1;
    } else {
        msg = "\nProgram shutting down due to inactivity.\n";
        if (write(STDOUT_FILENO, msg, strlen(msg)) < 0) { }

        _exit(EXIT_FAILURE);
    }

    if (write(STDOUT_FILENO, msg, strlen(msg)) < 0) { }
    if (write(STDOUT_FILENO, prompt_suffix, strlen(prompt_suffix)) < 0) { }
    alarm(next_alarm_time);
}

static void child_menu() {
    puts("\nMenu:");
    puts("1) Add card");
    puts("2) Delete card (by name)");
    puts("3) List cards");
    puts("4) Save to file");
    puts("5) Sort cards");
    puts("6) Exit");
}

static void child_chomp(char* s) {
    if (!s) return;
    size_t n = strlen(s);
    if (n > 0 && s[n-1] == '\n') s[n-1] = '\0';
}

static void child_prompt_line(const char* prompt, char* buf, size_t size) {
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(buf, (int)size, stdin)) { clearerr(stdin); continue; }
        child_chomp(buf);
        if (buf[0] == '\0') { puts("Input cannot be empty."); continue; }
        return;
    }
}

static int child_prompt_int(const char* prompt) {
    char line[128]; int v;
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { clearerr(stdin); continue; }
        if (sscanf(line, "%d", &v) == 1 && v >= 0) return v;
        puts("Enter a non-negative integer: ");
    }
}

static double child_prompt_double(const char* prompt) {
    char line[128]; double v;
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { clearerr(stdin); continue; }
        if (sscanf(line, "%lf", &v) == 1 && v >= 0.0) return v;
        puts("Enter a non-negative number (e.g., 12.34): ");
    }
}

static int child_prompt_menu_choice(const char* prompt) {
    char line[128];
    int choice;

    fputs(prompt, stdout);
    fflush(stdout);

    if (!fgets(line, sizeof line, stdin)) {
        clearerr(stdin);
        return -1;
    }

    g_child_inactivity_level = 0;
    alarm(5);

    if (sscanf(line, "%d", &choice) != 1) {
        return -2;
    }
    return choice;
}