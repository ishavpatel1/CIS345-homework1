#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pokemon.h"
#include "pokemon_access.h"
#include "card_collection.h"
#include "sorts.h"

struct CardArray {
    PokemonCard** data; 
    size_t size;
    size_t capacity;
};


static void chomp(char* s) {
    if (!s) return;
    size_t n = strlen(s);
    if (n > 0 && s[n-1] == '\n') s[n-1] = '\0';
}

static void prompt_line(const char* prompt, char* buf, size_t size) {
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(buf, (int)size, stdin)) { clearerr(stdin); continue; }
        chomp(buf);
        if (buf[0] == '\0') { puts("Input cannot be empty."); continue; }
        return;
    }
}

static int prompt_int(const char* prompt) {
    char line[128]; int v;
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { clearerr(stdin); continue; }
        if (sscanf(line, "%d", &v) == 1 && v >= 0) return v;
        puts("Enter a non-negative integer.");
    }
}

static double prompt_double(const char* prompt) {
    char line[128]; double v;
    for (;;) {
        fputs(prompt, stdout); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { clearerr(stdin); continue; }
        if (sscanf(line, "%lf", &v) == 1 && v >= 0.0) return v;
        puts("Enter a non-negative number (e.g., 12.34).");
    }
}


static void ensure_capacity(CardArray* arr, size_t need) {
    if (need <= arr->capacity) return;
    while (arr->capacity < need) arr->capacity *= 2;
    PokemonCard** p = (PokemonCard**)realloc(arr->data, arr->capacity * sizeof(PokemonCard*));
    if (!p) { fprintf(stderr, "realloc failed\n"); exit(1); }
    arr->data = p;
}

static int find_index_by_name(const CardArray* arr, const char* name) {
    for (size_t i = 0; i < arr->size; i++) {
        if (strncmp(arr->data[i]->name, name, POKEMON_NAME_MAX) == 0) return (int)i;
    }
    return -1;
}


int compare_by_name(const void* a, const void* b) {
    const PokemonCard* cardA = *(const PokemonCard**)a;
    const PokemonCard* cardB = *(const PokemonCard**)b;
    return strcmp(cardA->name, cardB->name);
}

int compare_by_hit_points(const void* a, const void* b) {
    const PokemonCard* cardA = *(const PokemonCard**)a;
    const PokemonCard* cardB = *(const PokemonCard**)b;
    return cardA->hit_points - cardB->hit_points;
}

int compare_by_value(const void* a, const void* b) {
    const PokemonCard* cardA = *(const PokemonCard**)a;
    const PokemonCard* cardB = *(const PokemonCard**)b;
    if (cardA->dollar_value < cardB->dollar_value) return -1;
    if (cardA->dollar_value > cardB->dollar_value) return 1;
    return 0;
}



CardArray* create_collection(void) {
    CardArray* arr = (CardArray*)malloc(sizeof(CardArray));
    if (!arr) { fprintf(stderr, "malloc failed\n"); exit(1); }
    arr->size = 0;
    arr->capacity = 4;
    arr->data = (PokemonCard**)malloc(arr->capacity * sizeof(PokemonCard*));
    if (!arr->data) { fprintf(stderr, "malloc failed\n"); exit(1); }
    return arr;
}

void free_collection(CardArray* arr) {
    if (arr) {
        for (size_t i = 0; i < arr->size; i++) {
            free(arr->data[i]);
        }
        free(arr->data);
        free(arr);
    }
}

void add_card(CardArray* arr) {
    PokemonCard* new_card = (PokemonCard*)malloc(sizeof(PokemonCard));
    if (!new_card) { fprintf(stderr, "malloc failed\n"); exit(1); }

    char buf[128];
    prompt_line("Name: ", buf, sizeof buf); setName(new_card, buf);
    prompt_line("Type: ", buf, sizeof buf); setType(new_card, buf);
    
    setHitPoints(new_card, prompt_int("Hit Points: "));
    setValue(new_card, prompt_double("Dollar Value: "));
    
    ensure_capacity(arr, arr->size + 1);
    arr->data[arr->size++] = new_card;
    puts("Card added.");
}

void delete_card(CardArray* arr) {
    if (arr->size == 0) { puts("No cards to delete."); return; }
    char name[POKEMON_NAME_MAX];
    prompt_line("Name of card to delete: ", name, sizeof name);
    int idx = find_index_by_name(arr, name);
    if (idx < 0) { puts("Card not found."); return; }

    free(arr->data[idx]);

    for (size_t i = (size_t)idx + 1; i < arr->size; i++) {
        arr->data[i - 1] = arr->data[i];
    }
    arr->size--;
    puts("Card deleted.");
}

void list_cards(const CardArray* arr) {
    if (arr->size == 0) { puts("(no cards)"); return; }
    for (size_t i = 0; i < arr->size; i++) {
        int need = getToStringLength(arr->data[i]);
        char* s = (char*)malloc((size_t)need);
        if (!s) { fprintf(stderr, "malloc failed\n"); exit(1); }
        toString(arr->data[i], s);
        printf("%zu) %s\n", i + 1, s);
        free(s);
    }
}

void save_to_file(const CardArray* arr, const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) { perror("fopen"); return; }
    for (size_t i = 0; i < arr->size; i++) {
        fprintf(f, "%s\t%s\t%d\t%.2f\n",
            arr->data[i]->name,
            arr->data[i]->type,
            arr->data[i]->hit_points,
            arr->data[i]->dollar_value);
    }
    fclose(f);
    printf("Saved %zu card(s) to '%s'.\n", arr->size, path);
}

void load_from_file(CardArray* arr, const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) return;
    char line[256];
    while (fgets(line, sizeof line, f)) {
        chomp(line);
        if (line[0] == '\0') continue;
        
        PokemonCard* c = (PokemonCard*)malloc(sizeof(PokemonCard));
        if (!c) { fprintf(stderr, "malloc failed\n"); exit(1); }

        char name[POKEMON_NAME_MAX], type[POKEMON_TYPE_MAX];
        int hp; double val;

        if (sscanf(line, "%63[^\t]\t%31[^\t]\t%d\t%lf", name, type, &hp, &val) == 4) {
            setName(c, name); setType(c, type);
            setHitPoints(c, hp); setValue(c, val);
            ensure_capacity(arr, arr->size + 1);
            arr->data[arr->size++] = c;
        } else {
            free(c);
        }
    }
    if (arr->size > 0) {
        printf("Loaded %zu card(s) from '%s'.\n", arr->size, path);
    }
    fclose(f);
}

void sort_cards(CardArray* arr) {
    if (get_collection_size(arr) < 2) {
        puts("You need at least two cards to sort.");
        return;
    }

    puts("\nSort by:");
    puts("1) Name");
    puts("2) Hit Points");
    puts("3) Dollar Value");

    char line[128];
    int choice;
    for (;;) {
        fputs("Select: ", stdout);
        fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) {
            clearerr(stdin);
            continue;
        }
        if (sscanf(line, "%d", &choice) == 1 && choice >= 1 && choice <= 3) {
            break;
        }
        puts("Invalid choice. Please enter 1, 2, or 3.");
    }
    
    typedef int (*CardCompareFunc)(const void*, const void*);
    CardCompareFunc sorter = NULL;
    const char* sort_key = "Unknown";

    if (choice == 1) {
        sorter = compare_by_name;
        sort_key = "Name";
    } else if (choice == 2) {
        sorter = compare_by_hit_points;
        sort_key = "Hit Points";
    } else if (choice == 3) {
        sorter = compare_by_value;
        sort_key = "Dollar Value";
    }

    if (sorter) {
        printf("\n--- Sorting collection by %s ---\n", sort_key);
        selection_sort(arr->data, arr->size, sizeof(PokemonCard*), sorter);
        list_cards(arr);
    }
}

size_t get_collection_size(const CardArray* arr) {
    if (!arr) {
        return 0;
    }
    return arr->size;
}