#include <stdlib.h>
#include <string.h>
#include "sorts.h"

void selection_sort(void* base, size_t num, size_t size, int (*compar)(const void*, const void*)) {
    if (num < 2) {
        return; // No need to sort 0 or 1 elements
    }

    char* arr = (char*)base;
    char* temp = (char*)malloc(size);
    if (!temp) {
        return; // Malloc failure, cannot sort
    }

    for (size_t i = 0; i < num - 1; i++) {
        size_t min_idx = i;
        for (size_t j = i + 1; j < num; j++) {
            // Get pointers to the elements to be compared
            void* elem1 = (void*)(arr + min_idx * size);
            void* elem2 = (void*)(arr + j * size);

            if (compar(elem1, elem2) > 0) {
                min_idx = j;
            }
        }

        if (min_idx != i) {
            // Get pointers to the elements to be swapped
            void* elem_i = (void*)(arr + i * size);
            void* elem_min = (void*)(arr + min_idx * size);

            // Swap using memcpy
            memcpy(temp, elem_i, size);
            memcpy(elem_i, elem_min, size);
            memcpy(elem_min, temp, size);
        }
    }

    free(temp);
}