#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <ctype.h>
#include <errno.h>

#define PORT 2223
#define MAX_STRING_LEN 64

typedef struct {
    char str[MAX_STRING_LEN];
    char c;
    short s;
    int i;
    long l;
    float f;
    double d;
} DataPacket;

void print_packet(const char *label, const DataPacket *p) {
    printf("\n--- %s ---\n", label);
    printf("String   (str): \"%s\"\n", p->str);
    printf("Char     (c):   '%c'\n", p->c);
    printf("Short    (s):   %hd\n", p->s);
    printf("Int      (i):   %d\n", p->i);
    printf("Long     (l):   %ld\n", p->l);
    printf("Float    (f):   %.2f\n", p->f);
    printf("Double   (d):   %.2f\n", p->d);
    printf("-------------------\n");
}

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(void) {
    int listen_fd, conn_fd;
    socklen_t client_len;
    struct sockaddr_in serv_addr, client_addr;
    ssize_t n;
    
    DataPacket initial_data = {
        .str = "Hello World.",
        .c = 'a',
        .s = 100,
        .i = 5000,
        .l = 9876543210L,
        .f = 12.5f,
        .d = 1024.75
    };

    printf("Server starting...\n");
    print_packet("Initial Data SENT to Client", &initial_data);

    listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        error("ERROR opening socket");
    }

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(PORT);

    if (bind(listen_fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        error("ERROR on binding");
    }

    listen(listen_fd, 5);
    printf("Server listening on port %d...\n", PORT);

    client_len = sizeof(client_addr);
    conn_fd = accept(listen_fd, (struct sockaddr *) &client_addr, &client_len);
    if (conn_fd < 0) {
        error("ERROR on accept");
    }
    printf("Client connected. Starting data exchange.\n");

    DataPacket tx_packet = initial_data;

    tx_packet.s = htons(initial_data.s);
    tx_packet.i = htonl(initial_data.i);

    n = write(conn_fd, &tx_packet, sizeof(DataPacket));
    if (n < 0) {
        error("ERROR writing to socket");
    }
    printf("Initial data packet sent to client (%zu bytes).\n", sizeof(DataPacket));


    DataPacket rx_packet;
    memset(&rx_packet, 0, sizeof(DataPacket));

    n = read(conn_fd, &rx_packet, sizeof(DataPacket));
    if (n < 0) {
        error("ERROR reading from socket");
    }
    if (n != sizeof(DataPacket)) {
        printf("WARNING: Read %zd bytes, expected %zu.\n", n, sizeof(DataPacket));
    }
    printf("Processed data packet received from client (%zd bytes).\n", n);

    rx_packet.s = ntohs(rx_packet.s);
    rx_packet.i = ntohl(rx_packet.i);

    print_packet("Final Data RECEIVED from Client", &rx_packet);

    close(conn_fd);
    close(listen_fd);
    printf("Connection closed. Server shutting down.\n");

    return 0;
}