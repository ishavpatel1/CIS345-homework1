#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <ctype.h>

#define PORT 2223
#define MAX_STRING_LEN 64

typedef struct {
    char str[MAX_STRING_LEN];
    char c;
    short s;
    int i;
    long l;
    float f;
    double d;
} DataPacket;


void print_packet(const char *label, const DataPacket *p) {
    printf("\n--- %s ---\n", label);
    printf("String   (str): \"%s\"\n", p->str);
    printf("Char     (c):   '%c'\n", p->c);
    printf("Short    (s):   %hd\n", p->s);
    printf("Int      (i):   %d\n", p->i);
    printf("Long     (l):   %ld\n", p->l);
    printf("Float    (f):   %.2f\n", p->f);
    printf("Double   (d):   %.2f\n", p->d);
    printf("-------------------\n");
}

void reverse_string(char *str) {
    int len = strlen(str);
    for (int i = 0; i < len / 2; i++) {
        char temp = str[i];
        str[i] = str[len - 1 - i];
        str[len - 1 - i] = temp;
    }
}

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
    int sockfd;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    ssize_t n;
    DataPacket packet;

    if (argc < 2) {
        fprintf(stderr, "Usage: %s <hostname>\n", argv[0]);
        exit(1);
    }

    printf("Client starting...\n");

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        error("ERROR opening socket");
    }

    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr, "ERROR, no such host: %s\n", argv[1]);
        exit(1);
    }

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    memcpy((char *)&serv_addr.sin_addr.s_addr, (char *)server->h_addr, server->h_length);
    serv_addr.sin_port = htons(PORT);

    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        error("ERROR connecting");
    }
    printf("Connected to server: %s\n", argv[1]);


    n = read(sockfd, &packet, sizeof(DataPacket));
    if (n < 0) {
        error("ERROR reading from socket");
    }
    if (n != sizeof(DataPacket)) {
        printf("WARNING: Read %zd bytes, expected %zu.\n", n, sizeof(DataPacket));
    }
    printf("Initial data packet received from server (%zd bytes).\n", n);

    packet.s = ntohs(packet.s);
    packet.i = ntohl(packet.i);

    print_packet("Original Data RECEIVED from Server", &packet);


    printf("\nProcessing data...\n");

    reverse_string(packet.str);

    if (isalpha(packet.c)) {
        packet.c = toupper(packet.c);
    } 

    packet.s += 1;

    packet.i *= 2;

    packet.l *= 3;

    packet.f /= 2.0f;

    packet.d /= 4.0;

    print_packet("Processed Data READY to Send Back", &packet);


    DataPacket tx_packet = packet;

    tx_packet.s = htons(packet.s);
    tx_packet.i = htonl(packet.i);

    n = write(sockfd, &tx_packet, sizeof(DataPacket));
    if (n < 0) {
        error("ERROR writing to socket");
    }
    printf("Processed data packet sent back to server (%zu bytes).\n", sizeof(DataPacket));


    close(sockfd);
    printf("Connection closed. Client shutting down.\n");

    return 0;
}