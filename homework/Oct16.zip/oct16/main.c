#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include <unistd.h>
#include<math.h>

int main(int argc, char *argv[]){
    if(argc < 2){
        fprintf(stderr, "Usage: %s coeff0 coeff1 ... coeffN\n", argv[0]);
        return 1;
    }

    int n = argc - 1;
    double coeffs[n];
    for(int i = 0; i < n; i++){
        coeffs[i] = atof(argv[i+1]);
    }
        int pipes[n+1][2];
        for(int i = 0; i <= n; i++)
        pipe(pipes[i]);

        for(int i = 0; i < n; i++){
            if(fork() == 0){
                for(int j = 0; j <=n; j++){
                    if(j != i) close(pipes[j][0]);
                    if(j != i +1) close(pipes[j][1]);
                }

                double X, sum;
                int power = n - 1 - i;
                while (read(pipes[i][0], &X, sizeof(double)) > 0 &&
                        read(pipes[i][0], &sum, sizeof(double)) >0){
                            sum+= coeffs[i] * pow(X, power);
                            write(pipes[i+1][1], &X, sizeof(double));
                            write(pipes[i+1][1], &sum, sizeof(double));
                        }
                close(pipes[i][0]);
                close(pipes[i+1][1]);
                _exit(0);
            }
        }

        for(int i = 0; i < n; i++){
            close(pipes[i][0]);
            close(pipes[i+1][1]);
        }   

        double X, sum;
        char line[100];

        while(1){
            printf("Enter a value for X (blank to end): ");
            fflush(stdout);

            if(!fgets(line, sizeof(line), stdin)){
                printf("\n End of input detected. Program terminated. \n");
                break;
            }

            if(line[0] == '\n'){
                printf("No input detected - program terminated! \n");
                break;
            }

            X = atof(line);
            sum = 0.0;

            write(pipes[0][1], &X, sizeof(double));
            write(pipes[0][1], &sum, sizeof(double));

            read(pipes[n][0], &X, sizeof(double));
            read(pipes[n][0], &sum, sizeof(double));

            printf("Result: %.2f\n\n", sum);
        }
        close(pipes[0][1]);
        close(pipes[n][0]);

        printf("Exiting....\n");
        return 0;
     
}