#include <stdio.h>
	
	void printSums(int a, int b, int c){
	
	printf("\n--- Pairwise Sums ---\n");
    printf("a + b = %d\n", a + b);
    printf("a + c = %d\n", a + c);
    printf("b + c = %d\n", b + c);
	}
    
    void printProducts(int a , int b, int c){
	printf("\n--- Pairwise Products ---\n");
    printf("a * b = %d\n", a * b);
    printf("a * c = %d\n", a * c);
    printf("b * c = %d\n", b * c);
	}	
    
    void printDifference(int a, int b, int c){
    printf("\n--- Pairwise Differences ---\n");
    printf("a - b = %d\n", a - b);
    printf("b - a = %d\n", b - a);
    printf("a - c = %d\n", a - c);
    printf("c - a = %d\n", c - a);
    printf("b - c = %d\n", b - c);
    printf("c - b = %d\n", c - b);
	}
    
    void printQuotient(int a, int b, int c){
    printf("\n--- Pairwise Quotients (Integer) ---\n");
 
    if (b != 0) printf("a / b = %d\n", a / b);
    else printf("a / b = undefined (division by zero)\n");
 
    if (a != 0) printf("b / a = %d\n", b / a);
    else printf("b / a = undefined (division by zero)\n");
 
    if (c != 0) printf("a / c = %d\n", a / c);
    else printf("a / c = undefined (division by zero)\n");
 
    if (a != 0) printf("c / a = %d\n", c / a);
    else printf("c / a = undefined (division by zero)\n");
 
    if (c != 0) printf("b / c = %d\n", b / c);
    else printf("b / c = undefined (division by zero)\n");
 
    if (b != 0) printf("c / b = %d\n", c / b);
    else printf("c / b = undefined (division by zero)\n");
 
    printf("\n--- Pairwise Quotients (Floating Point) ---\n");
 
    if (b != 0) printf("a / b = %.2f\n", (float)a / b);
    else printf("a / b = undefined (division by zero)\n");
 
    if (a != 0) printf("b / a = %.2f\n", (float)b / a);
    else printf("b / a = undefined (division by zero)\n");
 
    if (c != 0) printf("a / c = %.2f\n", (float)a / c);
    else printf("a / c = undefined (division by zero)\n");
 
    if (a != 0) printf("c / a = %.2f\n", (float)c / a);
    else printf("c / a = undefined (division by zero)\n");
 
    if (c != 0) printf("b / c = %.2f\n", (float)b / c);
    else printf("b / c = undefined (division by zero)\n");
 
    if (b != 0) printf("c / b = %.2f\n", (float)c / b);
    else printf("c / b = undefined (division by zero)\n");
	}
