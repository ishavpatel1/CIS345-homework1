#include <stdio.h>
#include <stdlib.h>

void add_p(int a, int b, int c){
    printf("%d + %d = %d\n", a, b, a + b);
    printf("%d + %d = %d\n", b, c, b + c);
    printf("%d + %d = %d\n", c, a, c + a);
}

void mult_p(int a, int b, int c){
    printf("%d * %d = %d\n", a, b, a * b);
    printf("%d * %d = %d\n", b, c, b * c);
    printf("%d * %d = %d\n", c, a, c * a);
}

void sub_p(int a, int b, int c){
    printf("%d - %d = %d\n", a, b, a - b);
    printf("%d - %d = %d\n", b, a, b - a);
    printf("%d - %d = %d\n", b, c, b - c);
    printf("%d - %d = %d\n", c, b, c - b);
    printf("%d - %d = %d\n", c, a, c - a);
    printf("%d - %d = %d\n", a, c, a - c);
}

void div_p(int a, int b, int c){
    dec_div(a, b);
    dec_div(b, a);
    dec_div(b, c);
    dec_div(c, b);
    dec_div(c, a);
    dec_div(a, c);

    frac_div(a, b);
    frac_div(b, a);
    frac_div(b, c);
    frac_div(c, b);
    frac_div(c, a);
    frac_div(a, c);
}

void dec_div(int a, int b){
    printf("%d / %d = ", a, b);
    if(b == 0){
        printf("undefined\n");
        return;
    }

    double v = ((double)(a))/(b);
    printf("%f\n", v);
}

void frac_div(int a, int b){
    printf("%d / %d = ", a, b);
    if(b == 0){
        printf("undefined\n");
        return;
    }
    printf("%d\n", a / b);
}