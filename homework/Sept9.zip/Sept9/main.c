#include <stdio.h>
#include <stdlib.h>

#include "utility.c"

int main(){
    int a, b, c;

    printf("Please Enter X Y Z");
    scanf("%d %d %d", &a, &b, &c);

    add_p(a, b, c);
    sub_p(a, b, c);
    mult_p(a, b, c);
    div_p(a, b, c);
}