#ifndef CARD_COLLECTION_H
#define CARD_COLLECTION_H

#include <stddef.h>

typedef struct CardArray CardArray;

#define SORT_BY_NAME 1
#define SORT_BY_HP   2
#define SORT_BY_VALUE 3


CardArray* create_collection(void);
void free_collection(CardArray* arr);
void load_from_file(CardArray* arr, const char* path);
void save_to_file(const CardArray* arr, const char* path);
void add_card(CardArray* arr);
void delete_card(CardArray* arr);
void list_cards(const CardArray* arr);

void sort_cards(CardArray* arr);

size_t get_collection_size(const CardArray* arr);

#endif 