#ifndef POKEMON_ACCESS_H
#define POKEMON_ACCESS_H


#include "pokemon.h"

void getName(Pokemon* theRecord, char* spotToCopyName);
void getType(Pokemon* theRecord, char* spotToCopyTheType);
int getHitPoints(Pokemon* theRecord);
float getDollarValue(Pokemon* theRecord);

void setName(Pokemon* theRecord, const char* newName);
void setType(Pokemon* theRecord, const char* newName);
void setHitPoints(Pokemon* theRecord, int newHitPoints);
void setDollarValue(Pokemon* theRecord, float newDollarValue);

#endif