#include <stdio.h>
#include "pokemon.h"
#include "pokemon_access.h"

#define NUM_CARDS 3

int main()
{
    Pokemon cards[NUM_CARDS];
    char tempName[50], tempType[30];
    
    for (int i = 0; i < NUM_CARDS; i++)
    {
        printf("Enter the data for the Pokemon card %d:\n", i + 1);

        printf("Name: ");
        scanf("%49s", tempName);
        setName(&cards[i], tempName);

        printf("Type (Electric, Water...): ");
        scanf("%29s", tempType);
        setType(&cards[i], tempType);

        int hp;
        printf("Hit points: ");
        scanf("%d", &hp);
        setHitPoints(&cards[i], hp);

        float value;
        printf("Dollar Value: ");
        scanf("%f", &value);
        setDollarValue(&cards[i], value);

        while (getchar() != '\n');

        printf("\n");
    }

    printf("--Display format 1: Name, Type, Hit Points, Dollar Value --\n");
    for (int i = 0; i < NUM_CARDS; i++)
    {
        getName(&cards[i], tempName);
        getType(&cards[i], tempType);
        printf("%s, %s, %d, $%.2f\n",
               tempName,
               tempType,
               getHitPoints(&cards[i]),
               getDollarValue(&cards[i]));
    }

    printf("\n");

    printf("--Display format 2: Dollar Value, Hit Points, Name, Type --\n");
    for (int i = 0; i < NUM_CARDS; i++)
    {
        getName(&cards[i], tempName);
        getType(&cards[i], tempType);
        printf("$%.2f, %d, %s, %s\n",
               getDollarValue(&cards[i]),
               getHitPoints(&cards[i]),
               tempName,
               tempType);
    }
return 0;
}
